


def test():
    pass


# 첫번째 함수이름 test (매개인자)
# 두번째 test('code'=2400, 'title'= 'summer', 'grade'='A')
# 세번째 test함수에서 코드 2400 제목 summer  등급 A 
# 세번째 test함수에서 코드 2400 title summer  grade A 