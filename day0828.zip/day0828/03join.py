# 03join.py

url = 'www.google.com'
print(url)

myret = url.split('.') #['www', 'google', 'com'] 

ct = '  '            #'공백' join연결하면 효과 1배확대 
print(ct.join(url)) #w w w . g o o g l e . c o m







print()