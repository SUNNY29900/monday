#04find.py
#교재86~90페이지 참고


msg='bstzpcomonhEReey'

pos= msg.find('com')   #한 문자도 가능하지만 한 단어도 가능
if pos==-1: 
     pass
else:
     pass
     #있으면 출력을 하거나 조작, 연산처리
     print('원하는 키워드가 없습니다')
print('common키워드가 없습니다')

print()
print('.'*50)


