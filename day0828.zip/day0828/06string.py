#06string.py


msg='''

slkjdowif~~
우리나라   
대한민국  '''

print()

info='''금수강산sdosd'
화려강산'''                