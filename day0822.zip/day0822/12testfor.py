#testfor12.py

#for 대표변수 처리
#반복 - for, while
#반복에서 보조제어문 break반복탈출, continue복귀 
for k in range(1,11) :
    if k==5 : 
        continue
    print(k, end='')

     #보조제어, break문장 기술 if==5: break
     #보조제어  continue문장 기술
     
     #1 2 3 4 6 7 8 9 10



