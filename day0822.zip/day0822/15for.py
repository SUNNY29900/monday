#15for.py


#for반복문 대표변수 사용 range(시, 최, 증감)
#10  9  8  7  6  5  4  3  2  1 
#for k in range (1,11):
#print(k)

for i in range(10, 0, -1):
      print(i)
                   


print()