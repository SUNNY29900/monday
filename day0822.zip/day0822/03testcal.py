#03testcal.py

#변수선언 및 초기화
a, b = 7,2
hap, sub, gob, mok, nmg=0,0,0,0,0  #산술연산
x,y,z=False,False,False            #0초기화보다는 false권장

hap=a+b
print(a+b)
print(hap)
print('-'*50)

x=(a>b)
print(a>b)     #결과값 상상
print(x)


#관계연산 > < >= <= == !=
y=(a==b)
z=(a!=b)
print(y)        #false
print(z)        #false
#a,b=7,2

print()


