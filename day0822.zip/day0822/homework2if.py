#homework2if.py



su = 6
# 정수=int=integer
# 문제해결 su데이터값 짝수, 홀수
# if~else

# mok = su % 2      #홀짝을 할때는 / 이 아니라 %
if su%2 != 0 :
    print(su, '홀수입니다')
else :
    print(su, '짝수입니다')

if su%2 == 0 :
    print(su, '짝수입니다')
else :
    print(su, '홀수입니다')

print('- ' * 50)
print()


