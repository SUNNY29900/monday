#14breakcontinue.py

#break continue보조제어문 단독사용 에러발생
a='우리나라'
b='금수나라'
#continue
c='화려강산'

#if제어문에서 break continue보조제어문 사용금지
#반복문에서 break continue 사용
su=-7
if su<0 :
    print(su, '음수')
# break
elif su ==0:
    print(su, '제로')
elif su>0:
    pass
    print(su, '양수')
else:
    pass
    print('숫자데이터가 아닙니다')


    # #if~else   if~elif~else
    # #for
    # #while
    # #중첩사용=포함해서 사용
    # for k in range(1,101,1):
    #     for j in range(1,6,1):
    #         pass
    
    # if su<0:
    #     pass
    #     for i in range(1,1001,1):
    #         pass
    # else: 
    #     pass 