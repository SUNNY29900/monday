#05testif.py


'''
제어 if
제어 if~else 
제어 if~elif~else 
'''

count=5          #비권장
cnt=5            #권장
mycount=5        #권장

if cnt>=5: 
   print('게임종료되었습니다')
   print('다음에 도전하세요')

#에러이유  UNEXPECTED indentation
#종종 에러 이유 Unindent 들여쓰기 indent
print('이글스 A')    
print('라이온 B')
print('타이거 C')
print('베어스 D')
print()