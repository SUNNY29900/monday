# 숙제 homeworkcal.py
a,b,ret =9,5,0
hap, sub, gob,mok=0,0,0,0
mok=0.0
ret=a*b

#hap=a+b
#sub=a-b
#gob=a*b
#mok=a/b
#nmg=a%b

print(a+b)  #hap=a+b
print(a-b)  #sub=a-b
print(a, '*', b, '=', ret)
print(a*b)  #gob=a*b
print(f'{a}*{b}={ret}')
print(a/b)  #mok=a/b
print(a//b) #정수 부분의 몫만 보여줌
print(a%b)  #나누기 했을때 나머지 값을 보여줌
print(a%b)  #nmg=a%b


print()


#print( % {} f{}) 다양한 출력

...
#9+5=14
#9-5=4
#9*5=45
#9/5=1
#9%5=4
...

#참고 #03testprint.py문서

