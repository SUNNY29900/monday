#07testround.py

#변수 하나씩 선언, 다중선언
a, b, ret = 9, 4, 0
mok=934.5637
print('%.2f'%(mok))  # %f 결과 934.56 자릿수 지정
print(round(mok,2))  #round(값,2) 결과 034.56

# 내장함수
# print(), int(), type(), input('안내문'), str() sum()
# round(데이터, 실수자릿수2)

# %자릿수 d정수 %자릿수 f실수
# 원하는 영역 블럭 선택후 ctrl +/슬래시
# 곱하기 연산처리
