#bbb.py 문서
print(2+3)
print(34+3)
print()
print("개나리")
print("진달래")
print()
print('rain')
print("snow")
print("snow")
print()#맨마지막 라인개행