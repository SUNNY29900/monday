# 2024-08-21
# writer : 선슬기

print('이희동')
print(2+7)
print() #라인개행역할 <br>
