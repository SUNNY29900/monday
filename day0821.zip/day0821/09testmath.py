# 09 testmath.py
import math


a=25
b=5
print(math.sqrt(a))  #5.0    실수형태
print(math.pow(b,2)) #25.0   실수형태
print(math.pow(b,3)) #125.0  실수형태

# square +root = sqrt
# pow=power*2
# math라이브러리 결과값이 실수형태
# 내장함수 print(). round(숫자, 자릿수), int(), type()
# 함수사용시 꼭 추가 키워드, import라이브러리
#mok=934.5637
#print(round(mok,2))   #내장함수 round(값, 2) 934.56