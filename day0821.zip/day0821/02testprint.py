#02testprint.py

#변수 하나씩 선언, 다중선언

a=7
b=4
ret=0 #결과 result 축약한 변수이름

a=39
print(a)

a=27
print(a)

print()