# 선언부분=변수데이터 초기화= declare
title: '데이터 점수' 
name= '슬기'
kor=100
eng=80
ma=90
sci=95
hap=0  
avg=0.0




# 로직=연산
hap=kor+eng+ma+sci
avg=hap/4

#처리결과 출력 print('안내문',데이터)
print('이름=', name)
print('국어=', kor)
print('영어=', eng)
print('수학=', ma)
print('과학=', sci)
print('총점=', hap)
print('평균=', avg)
print()

