# 08 testcal. py

a=7
b=5

print(a*2)       #7*2  
print(b*2)       #5*2
print()
print(a**2)      #**제곱, 7*7
print(b*2)       #5*5
print()

print(' 결과몫=', 19/3)   #6.33333333333
print(' 결과몫=', 19//3)     #몫연산//정수값만 출력
print(' 나머지=',19%3)      #나머지 연산
print()
